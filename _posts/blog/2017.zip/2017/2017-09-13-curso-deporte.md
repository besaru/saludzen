---
layout: post
categories: blog
title:  Nuevo curso de fin de semana
subtitle: "Nuevo curso de fin de semana: Nutrición Energética, Actividad Física y Deporte"
date: 2017-09-13 21:11:27
author: Salud-Zen
image: img/eventos/071017Deporte_prop.jpg
linkfacebook: https://www.facebook.com/sharer/sharer.php?u=http%3A%2F%2Fwww.salud-zen.com%2Fblog%2F2017%2F09%2F13%2Fcurso-deporte.html&amp;src=sdkpreparse
---
Sacamos nuevo curso de fin de semana,  [Nutrición Energética, Actividad Física y Deporte][curso]! Incluido además en la formación de consultor.  

No olvides <a href="mailto:estilodevida@salud-zen.com?Subject=Curso de Deporte-Reserva de Plaza&body=%0A%0A Me gustaría reservar una plaza para el curso de Nutrición Energética, Actividad Física y Deporte. Mis datos Personales son:%0A%0A   -Nombre:%0A%0A   -Apellidos:%0A%0A   -Fecha de nacimiento:%0A%0A   -Teléfono:%0A%0A">reservar tu plaza</a>, que los grupos son reducidos!

Feliz miércoles estrellitas

[curso]:  {{site.url}}{{site.baseurl}}/evento/2017/10/07/curso-deporte.html
