---
layout: post
categories: blog
title:  ¡Un fin de semana completo!
subtitle: "Un fin de semana completo: Curso Introducción y Taller de Meditación"
date: 2017-09-18 21:11:27
author: Salud-Zen
image: img/blog/2017-09-18-fin-semana-completo.png
linkfacebook: https://www.facebook.com/sharer/sharer.php?u=http%3A%2F%2Fwww.salud-zen.com%2Fblog%2F2017%2F09%2F18%2Ffin-semana-completo.html&amp;src=sdkpreparse
---
Otro fin de semana repleto de caritas de entusiasmo, ganas de aprender y compartir.Un éxito el Curso de Introducción del sábado y el Taller de Meditación del domingo. Mil gracias a todos por estar tan implicados y dispuestos.El día 14 de Octubre repetimos Curso de Introducción, aún no sabemos si podremos sacar otra edición hasta después de Navidad, así que reservad el día y la plaza que los cursos que vienen después os van a encantar ;) y sin la Introducción no podréis apuntaros porque sin las bases os faltaría mucha información! Feliz tarde Estrellitas!
