---
layout: post
categories: blog
title:  ¡Nueva fecha para Taller de Meditación!
subtitle: Nueva fecha de impartición para poder disfrutar de este taller
date: 2017-08-30 21:11:27
author: Salud-Zen
image: img/blog/2017-08-30-taller-meditacion.jpg
linkfacebook: https://www.facebook.com/sharer/sharer.php?u=http%3A%2F%2Fwww.salud-zen.com%2Fblog%2Fblog%2F2017%2F08%2F30%2Ftaller-meditacion.html&amp;src=sdkpreparse
---
Seguimos calentando motores... el día [17 de septiembre][agenda] se impartirá en la escuela un Taller de Meditación Taoista, no olvides <a href="mailto:estilodevida@salud-zen.com?Subject=Taller de Meditación-Reserva de Plaza-Taller Meditación&body=%0A%0A Me gustaría reservar una plaza para el taller de meditación. Mis datos Personales son:%0A%0A   -Nombre:%0A%0A   -Apellidos:%0A%0A   -Fecha de nacimiento:%0A%0A   -Teléfono:%0A%0A">reservar tu plaza</a>, ya quedan poquitas ;)


Feliz miércoles estrellitas

[agenda]: {{site.url}}{{site.baseurl}}/calendario/
