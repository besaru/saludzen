---
layout: post
categories: blog
title:  "Resumen - Curso Elemento Metal!!"
subtitle: "Resumen - Aprendiendo y reforzando nuestra Energía Metal y sanando pulmones e intestino Grueso!"
date: 2017-11-15 21:11:27
author: Salud-Zen
image: img/blog/141117Resumen-ElementoMetal_propw.png
linkfacebook: https://www.facebook.com/sharer/sharer.php?u=http%3A%2F%2Fwww.salud-zen.com%2Fblog%2F2017%2F11%2F15%2Fenergia-metal.html&amp;src=sdkpreparse
---
Aquí tenéis un resumen y las fotitos de este fin de semana! Aprendiendo y reforzando nuestra Energía Metal y sanando pulmones e intestino Grueso!

Gracias por vuestro interés, vuestra atención.

Un placer todo lo que recibimos cada curso.
