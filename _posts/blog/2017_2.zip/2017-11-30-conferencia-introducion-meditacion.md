---
layout: post
categories: blog
title:  "Conferencia - Introducción a la Meditación!!"
subtitle: "Conferencia Gratuita - Introducción a la Meditación!!"
date: 2017-11-30 21:11:27
author: Salud-Zen
image: img/eventos/141217IntroduccionMeditacion.jpg
linkfacebook: https://www.facebook.com/sharer/sharer.php?u=http%3A%2F%2Fwww.salud-zen.com%2Fblog%2F2017%2F11%2F30%2Fconferencia-introducion-meditacion.html&amp;src=sdkpreparse
---
El día <b>14 de diciembre</b> nos vemos en Espacio Macabeo (Moralzarzal) a todos los que queráis asistir a un [taller gratuito] [taller] para ver un poco qué es eso de la Meditación y observar todas las creencias creadas y empezar a valorar la potente herramienta que tenemos a nuestra disposición para hacernos el día a día muchísimo más fácil y amoroso. Continuamos con el Proyecto Luz y Consciencia.. esta vez, por la Sierra Madrileña ;)

No olvidéis llamar para reservar hueco hasta llenar aforo

Compartid con todo aquel que creáis puede interesar ;)

Gracias!! y Feliz jueves estrellitas!!

[taller]:{{site.url}}{{site.baseurl}}/evento/2017/12/14/introduccion-meditacion.html
