---
layout: post
categories: blog
title:  "Taller Práctico - Qui Gong"
subtitle: "Taller Práctico - Qui Gong, el arte milenario de la salud y la vitalidad"
date: 2017-12-05 11:11:27
author: Salud-Zen
image: img/eventos/211217QUIGONG.jpg
linkfacebook: https://www.facebook.com/sharer/sharer.php?u=http%3A%2F%2Fwww.salud-zen.com%2Fblog%2F2017%2F12%2F05%2Ftaller-qui-gong.html&amp;src=sdkpreparse
---
Buenos dias!! ☺

En la imagen adjunta teneis toda la información del [Taller Práctico de Qi Gong] [taller] de este mes de Diciembre.

Interesados contactar para <a href="mailto:estilodevida@salud-zen.com?Subject=Taller Qui Gong-Reserva de Plaza&body=%0A%0A Me gustaría reservar una plaza para el Taller Práctico de Qui Gong. Mis datos Personales son:%0A%0A   -Nombre:%0A%0A   -Apellidos:%0A%0A   -Fecha de nacimiento:%0A%0A   -Teléfono:%0A%0A">reserva </a>  de plaza.

Gracias!!

Feliz Puente.

[taller]:{{site.url}}{{site.baseurl}}/evento/2017/12/21/Qui-Gong.html
