---
layout: post
categories: blog
title:  "Taller - Danza Terapéutica Transpersonal"
subtitle: "Taller - Danza Terapéutica Transpersonal"
date: 2017-12-28 22:00:27
author: Salud-Zen
image: img/eventos/20180113TallerDanza.jpg
linkfacebook: https://www.facebook.com/sharer/sharer.php?u=http%3A%2F%2Fwww.salud-zen.com%2Fblog%2F2017%2F12%2F28%2Ftaller-danza-terapeutica.html&amp;src=sdkpreparse
---
Buenas tardes ☺, os dejo la información del siguiente [taller de danza terapéutica] [taller] que voy a hacer para empezar el año sintiendo, bailando y aprovechando la energia del invierno para ver que podemos soltar de lo que hay por ahi adentro y que cositas podemos empezar a poder aceptar y acoger con mucho mucho amor.

[taller]: {{site.url}}{{site.baseurl}}/evento/2018/01/13/taller-danza.html
