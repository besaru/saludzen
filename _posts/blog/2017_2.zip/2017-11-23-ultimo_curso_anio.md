---
layout: post
categories: blog
title:  "Formación - Último curso del año!!"
subtitle: "Formación - Último curso del año!! Taller de Cocina Macrobiótica Navideña y Festiva"
date: 2017-11-23 21:11:27
author: Salud-Zen
image: img/eventos/171217TallerCMNavidenayFestiva_prop.jpg
linkfacebook: https://www.facebook.com/sharer/sharer.php?u=http%3A%2F%2Fwww.salud-zen.com%2Fblog%2Fblog%2F2017%2F11%2F23%2Fultimo_curso_anio.html&amp;src=sdkpreparse
---
Aquí está el último curso del año. El día [17 de diciembre Taller de cocina Macrobiótica Navideña y Festiva][curso]. No olvidéis <a href="mailto:estilodevida@salud-zen.com?Subject=Taller de Cocina Macrobiótica Navideña y Festiva-Reserva de Plaza&body=%0A%0A Me gustaría reservar una plaza para el Taller de Cocina Macrobiótica Navideña y Festiva. Mis datos Personales son:%0A%0A   -Nombre:%0A%0A   -Apellidos:%0A%0A   -Fecha de nacimiento:%0A%0A   -Teléfono:%0A%0A">reservar </a> vuestra plaza... que luego os quedaréis sin probar los polvorones más ricos y saludables! ;) jejeje.

Feliz Jueves estrellitas.

[curso]:{{site.url}}{{site.baseurl}}/evento/2017/12/17/taller-navidad.html
