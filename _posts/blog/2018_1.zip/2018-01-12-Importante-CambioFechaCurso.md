---
layout: post
categories: blog
title: Importante - Cambio Fecha del Taller de Danza Terapéutica Transpersonal
subtitle: Importante - Cambio Fecha del Taller de Danza Terapéutica Transpersonal
date: 2018-01-12 09:11:27
author: Salud-Zen
image: img/eventos/210118TallerDanza.jpg
linkfacebook: https://www.facebook.com/sharer/sharer.php?u=http%3A%2F%2Fwww.salud-zen.com%2Fblog%2F2018%2F01%2F12%2FImportante-CambioFechaCurso.html&amp;src=sdkpreparse
---
Buenos días! 😊 Por problemas técnicos hemos tenido que cambiar la fecha para el [Taller de Danza Terapeútica][taller] al día <b>21 de Enero</b>, esperamos que este día podáis compartir muchos más con nosotros este momento.


Si estás interesado, no olvides <a href="mailto:estilodevida@salud-zen.com?Subject=Taller - Danza Terapéutica Transpersonal-Reserva de Plaza&body=%0A%0A Me gustaría reservar una plaza para el Taller - Danza Terapéutica Transpersonal del 21 de Enero. Mis datos Personales son:%0A%0A   -Nombre:%0A%0A   -Apellidos:%0A%0A   -Fecha de nacimiento:%0A%0A    -Correo Electrónico:%0A%0A  -Teléfono:%0A%0A">reservar tu plaza</a>.

Un abrazo y feliz fin de semana.

[taller]: {{site.url}}{{site.baseurl}}/evento/2018/01/21/taller-danza.html
