---
layout: post
categories: blog
title:  ¡Publicación del Calendario con nuevas actividades!
subtitle: ¡Publicación del Calendario con nuevas actividades!
date: 2018-01-04 15:11:27
author: Salud-Zen
image: img/blog/2018-01-04-cursos-publicacion.jpg
linkfacebook: https://www.facebook.com/sharer/sharer.php?u=http%3A%2F%2Fwww.salud-zen.com%2Fblog%2F2018%2F01%2F04%2Fpublicacion-calendario.html&amp;src=sdkpreparse
---
Aquí teneis las nueva actividades para los próximos meses, puedes consultarlas en nuestro [calendario][agenda]. Os proponemos gran variedad de actividades, cursos,talleres,charlas ...

Entre estas actividades  ofrecemos un [Taller de Cosmética Natural] [cosmetica], se trata de una colaboración con la escuela, que permite dar el enfoque holístico. Iremos invitando a gente de fuera de la escuela con otras disciplinas distintas a lo que nosotros hacemos.

Esperamos que os gusten, y recuerda reservar tu plaza,




[agenda]: {{site.url}}{{site.baseurl}}/calendario/
[cosmetica]:{{site.url}}{{site.baseurl}}/evento/2018/02/17/taller-cosmetica.html
