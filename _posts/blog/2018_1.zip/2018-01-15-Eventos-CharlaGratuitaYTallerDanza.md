---
layout: post
categories: blog
title: Eventos - Conferencia Gratuita y Taller de Danza
subtitle: Eventos - Conferencia Gratuita y Taller de Danza, ¡no te los puedes perder!
date: 2018-01-15 09:11:27
author: Salud-Zen
image: img/blog/150118CharlaGratuitaYTallerDanza.jpg
linkfacebook: https://www.facebook.com/sharer/sharer.php?u=http%3A%2F%2Fwww.salud-zen.com%2Fblog%2F2018%2F01%2F12%2FImportante-CambioFechaCurso.html&amp;src=sdkpreparse
---
Buenos días de Invierno!

 Recordaos que esta semana tenemos dos eventos que no os podéis perder! Viernes 19 [conferencia gratuita sobre "El poder Curativo del agua"][charla] y el Domingo 21 [taller "Danza terapéutica"][taller].

No dejéis la reserva de plaza para el último día!

Feliz día estrellitas

[charla]: {{site.url}}{{site.baseurl}}/evento/2018/01/19/charla-agua.html
[taller]: {{site.url}}{{site.baseurl}}/evento/2018/01/21/taller-danza.html
