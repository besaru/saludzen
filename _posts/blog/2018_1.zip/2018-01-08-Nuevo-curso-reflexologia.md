---
layout: post
categories: blog
title: Curso - Reflexología Podal Holística
subtitle: Curso - Reflexología Podal Holística
date: 2018-01-08 09:11:27
author: Salud-Zen
image: img/eventos/010218Reflexologia1.jpg
linkfacebook: https://www.facebook.com/sharer/sharer.php?u=http%3A%2F%2Fwww.salud-zen.com%2Fblog%2F2018%2F01%2F08%2FNuevo-curso-reflexologia.html&amp;src=sdkpreparse
---
El próximo mes de Febrero arranca el curso de [Reflexología Podal Holística][reflexologia], se trata de una formación profesional de 4 meses de duración (Febrero - Mayo), donde todos los jueves durante 2 horas y media, se verá la reflexología podal desde un enfoque Anatómico Fisiológico, Psico-Emocional y Energético Integrado.

Si estás interesado, no olvides <a href="mailto:estilodevida@salud-zen.com?Subject=Curso de Reflexologia-Reserva de Plaza&body=%0A%0A Me gustaría reservar una plaza para el Curso de Reflexología Podal Holística (Feb - May'18). Mis datos Personales son:%0A%0A   -Nombre:%0A%0A   -Apellidos:%0A%0A   -Fecha de nacimiento:%0A%0A   -Teléfono:%0A%0A">reservar tu plaza</a>.


[reflexologia]:{{site.url}}{{site.baseurl}}/evento/2018/02/01/curso-reflexologia-podal.html
