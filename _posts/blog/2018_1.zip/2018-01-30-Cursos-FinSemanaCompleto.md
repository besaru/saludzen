---
layout: post
categories: blog
title: Resumen - Cursos Fin de semana completo
subtitle: Resumen - Cursos Fin de semana completo
date: 2018-01-30 09:11:27
author: Salud-Zen
image: img/blog/300118CursosFinDeSemana.jpg
linkfacebook: https://www.facebook.com/sharer/sharer.php?u=http%3A%2F%2Fwww.salud-zen.com%2Fblog%2F2018%2F01%2F30%2FCursos-FinSemanaCompleto.html&amp;src=sdkpreparse
---
Otro fin de Semana Increíble! El sábado un éxito el Taller de Constelaciones donde hubo movimientos maravillosos y el domingo volviendo a conectar con la cocina de nuestros ancestros ... se notó todo ese Qi en la cocina, estaba todo riquísimo! :) Ahí van unas fotitos para abrir el apetito. Feliz Martes estrellitas!

![Cocinando][img1]
![Asistentes][img2]
![Patatas][img3]
![Morcillas][img4]
![Crema][img5]
![Judiones][img6]
![Cocido][img7]





[img1]: {{site.url}}{{site.baseurl}}/img/blog/300118ManosAlaMasa.jpg "Cocinando"

[img2]: {{site.url}}{{site.baseurl}}/img/blog/300118Grupo.jpg "AsistentesCurso"

[img3]:{{site.url}}{{site.baseurl}}/img/blog/300118torreznos.jpg "Patatas revolconas con sus torreznitos especiales"
[img4]:{{site.url}}{{site.baseurl}}/img/blog/300118Morcilla.jpg "Las morcillitas del cocido... receta estrella"
[img5]:{{site.url}}{{site.baseurl}}/img/blog/300118CremaCatalana.jpg "Crema Catalana"
[img6]:{{site.url}}{{site.baseurl}}/img/blog/300118Judiones.jpg "Judiones con Almejas y Pulpo"
[img7]:{{site.url}}{{site.baseurl}}/img/blog/300118Cocido.jpg "Cocido, nos falta la sopita.. pero es que la devoraron..."
