---
layout: post
categories: blog
title:  Lectura - Pon el Cielo a Trabajar
subtitle: Lectura - Pon el Cielo a Trabajar
date: 2018-01-05 15:11:27
author: Salud-Zen
image: img/blog/050118PonElCieloATrabajar.jpg
linkfacebook: https://www.facebook.com/sharer/sharer.php?u=http%3A%2F%2Fwww.salud-zen.com%2Fblog%2F2018%2F01%2F05%2FLectura-PonElCieloATrabjar.html&amp;src=sdkpreparse
---
Queríamos compartir con todos vosotros el regalo que nos han traído los Reyes Magos, por adelantado, este año 2018, para poder regalároslo nosotros a vosotros también. ;)
Este regalo nos ha sido concedido tras pedirlo así en nuestra carta de Reyes :) :
"Queridos reyes Magos... Este año voy a pediros algo muy especial.

Me he ido dando cuenta a lo largo de todos estos años que no se Pedir y necesitaría ayuda divina...
Me gustaría que me enseñarais sobre el acto de Pedir en cualquier situación de mi día a día y no solo acordarme de pedir cuando tenga que enfrentarme a un gran problema de mi Vida.

Quiero aprender a manejar los poderes ilimitados de mi Ser como parte del Universo que soy.
Quiero abrir mi mente para traer el Cielo a la Tierra y pidiendo, poder ser libre, siendo dueño de mi Destino, Creador de mis Sueños y Capitán de mi Alma.
Quiero aprender a pedir en beneficio de la Humanidad para ayudar al Mundo a despertar y crear una Conciencia Social que busca el Bien para todos!!"
Namaste 🙏

Feliz día de Reyes!!

Lectura: [Pon el Cielo a Trabajar][libro]


[libro]: https://docs.google.com/viewer?a=v&pid=sites&srcid=ZGVmYXVsdGRvbWFpbnxzaWNvYmlvZW5lcmdldGljYXxneDozMzdkMDY1ZmVhZjg2YTJk
