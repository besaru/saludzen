---
layout: post
categories: blog
title: Receta - Bizcocho de arroz y algarroba
subtitle: Receta - Bizcocho de arroz y algarroba
date: 2018-01-19 09:11:27
author: Salud-Zen
image: img/blog/190118RecetaBizcocho.jpg
linkfacebook: https://www.facebook.com/sharer/sharer.php?u=http%3A%2F%2Fwww.salud-zen.com%2Fblog%2F2018%2F01%2F19%2FReceta-BizcochoArrozAlgarroba.html&amp;src=sdkpreparse
---
Hoy os dejamos una receta rica, rica para una buena merienda este fin de semana ;).

Feliz viernes dulces estrellitas :)

[Bizcocho de arroz y algarroba][receta]

Bon appetit!!

[receta]: {{site.url}}{{site.baseurl}}/postres/2018/01/19/bizcocho-arrozYalgarroba.html
