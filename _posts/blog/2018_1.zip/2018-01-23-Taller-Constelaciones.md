---
layout: post
categories: blog
title: Taller Constelaciones - Siempre estamos acompañados
subtitle: Taller Constelaciones - Siempre estamos acompañados
date: 2018-01-23 09:11:27
author: Salud-Zen
image: img/blog/230118TallerConstelaciones.jpg
linkfacebook: https://www.facebook.com/sharer/sharer.php?u=http%3A%2F%2Fwww.salud-zen.com%2Fblog%2F2018%2F01%2F23%2FTaller-Constelaciones.html&amp;src=sdkpreparse
---
"Siempre, estamos acompañados"... de nuestras Creencias, de nuestros Ancestros, de cada una de esas Estrellas que nos rodean y nos aportan distintos Aprendizajes, de Heridas Infantiles Creadas a veces de Necesidades no satisfechas por altas Expectativas... Pero siempre, estamos acompañados de la Luz que Somos, de un millón de Recursos internos que pueden con todas esas creencias que a veces usamos para autosabotearnos... Podemos poner un poco de "luz" a esas pequeñas "cosas" que nos " atascan" a nivel Inconsciente desde el trabajo Sistémico y las Constelaciones Familiares. Así que recordad que si queréis probar la experiencia, este Sábado hacemos un [Taller][taller] en la Escuela donde todos haremos algún Movimiento Sistémico y algunos podrán trabajar su propia Constelación Familiar.

 Feliz Martes estrellitas, y no olvidéis <a href="mailto:estilodevida@salud-zen.com?Subject=Taller - Constelaciones Familiares-Reserva de Plaza&body=%0A%0A Me gustaría reservar una plaza para el Taller - Constelaciones Familiares del 27 de Enero. Mis datos Personales son:%0A%0A   -Nombre:%0A%0A   -Apellidos:%0A%0A   -Fecha de nacimiento:%0A%0A    -Correo Electrónico:%0A%0A  -Teléfono:%0A%0A">reservar vuestra plaza</a> o pedirme más info.

 [taller]: {{site.url}}{{site.baseurl}}/evento/2018/01/27/taller-constelaciones.html
